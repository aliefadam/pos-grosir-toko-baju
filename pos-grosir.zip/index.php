<?php

header("Location: /view/pages/dashboard/index.php");
